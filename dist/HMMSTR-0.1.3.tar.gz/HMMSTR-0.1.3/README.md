# HMMSTR

HMMSTR is a bioinformatics software package for calling tandem reapeat copy number from raw, long-read, sequencing reads.
